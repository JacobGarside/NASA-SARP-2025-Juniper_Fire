Hi Sufian!

Here is a "merged" file with Aircraft data and AMS data.

The first few columns has data from the aircraft, like time after takeoff, latitude, longitude, altitude, speed, etc.
The last 5 columns has aerosol data, concentrations of Organics, Nitrates, Sulfates, Ammonium, and Chloride

We normally will grab some of the aircraft data and plot it with the aerosol measurements.  Like altitude with concentrations of the aerosol species.  

In IGOR we can also plot latitude vs longitude which can show a trace of where the plane has gone.  We can then add a 3rd dimension by changing the color of the flight path with the concentrations of different aerosols.  (Like what Eli showed you in class)

<3

Thank you!